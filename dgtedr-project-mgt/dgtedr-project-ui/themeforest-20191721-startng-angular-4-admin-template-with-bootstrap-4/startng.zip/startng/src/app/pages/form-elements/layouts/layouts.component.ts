import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-layouts',
  templateUrl: './layouts.component.html',
  encapsulation: ViewEncapsulation.None
})
export class LayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
